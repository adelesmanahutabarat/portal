<script src="{{ URL::asset('assets/js/vendor.min.js') }}"></script>
@stack('before-scripts')
<script src="{{ URL::asset('assets/js/app.min.js') }}"></script>
<script src="{{ URL::asset('assets/js/cleave.min.js') }}"></script> 
@stack('after-scripts')