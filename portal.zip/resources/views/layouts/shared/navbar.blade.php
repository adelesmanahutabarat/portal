@include('layouts.shared.header')
<div class="topnav shadow-sm">
    <div class="container-fluid">
        <nav class="navbar navbar-light navbar-expand-lg topbar-nav">
            <div class="collapse navbar-collapse" id="topnav-menu-content">
            @include('layouts.shared.app-menu')
            </div>
        </nav>
    </div>
</div>
