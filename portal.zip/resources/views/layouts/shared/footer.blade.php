<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
				{{ date('Y') }}  &copy; CAT. All Rights Reserved. Crafted with <i class='uil uil-heart text-danger font-size-12'></i> by <a href="https://benangkusut.com" target="_blank">serbengDev</a>
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->