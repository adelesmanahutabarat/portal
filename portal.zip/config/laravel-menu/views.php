<?php

return [
    'bootstrap-items' => 'laravel-menu::shreyu-navbar-items',
];
