<?php

return [
    'name' => 'Master'
];
