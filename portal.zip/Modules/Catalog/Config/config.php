<?php

return [
    'name' => 'Catalog'
];
