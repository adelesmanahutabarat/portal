<?php

return [
    'name' => 'Withdraw'
];
