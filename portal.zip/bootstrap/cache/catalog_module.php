<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Catalog\\Providers\\CatalogServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Catalog\\Providers\\CatalogServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);