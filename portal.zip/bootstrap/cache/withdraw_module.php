<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Withdraw\\Providers\\WithdrawServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Withdraw\\Providers\\WithdrawServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);